from Crypto.PublicKey import DSA
from Crypto.Hash import SHA256
from Crypto.Signature import DSS

class DSASigner:
    def __init__(self, key_size=2048):
        self.key_size = key_size
        self.private_key = None
        self.public_key = None

    def generate_keys(self):
        key = DSA.generate(self.key_size)
        self.private_key = key
        self.public_key = key.publickey()
        return key

    def save_keys(self, private_path, public_path):
        with open(private_path, 'wb') as f:
            f.write(self.private_key.export_key())
        with open(public_path, 'wb') as f:
            f.write(self.public_key.export_key())

    def load_private_key(self, path):
        with open(path, 'rb') as f:
            self.private_key = DSA.import_key(f.read())

    def load_public_key(self, path):
        with open(path, 'rb') as f:
            self.public_key = DSA.import_key(f.read())

    def sign_file(self, file_path):
        with open(file_path, 'rb') as f:
            data = f.read()
        hash_obj = SHA256.new(data)
        signer = DSS.new(self.private_key, 'fips-186-3')
        return signer.sign(hash_obj)

    def verify_signature(self, file_path, signature):
        with open(file_path, 'rb') as f:
            data = f.read()
        hash_obj = SHA256.new(data)
        verifier = DSS.new(self.public_key, 'fips-186-3')
        try:
            verifier.verify(hash_obj, signature)
            return True
        except ValueError:
            return False
