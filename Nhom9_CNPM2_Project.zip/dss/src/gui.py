import tkinter as tk
from tkinter import filedialog, messagebox
import os
from dsa import DSASigner

signer = DSASigner()

class DSSGuiApp:
    def __init__(self, root):
        self.root = root
        self.root.title("ỨNG DỤNG KÝ SỐ DSS")
        self.root.geometry("600x500")
        self.selected_file = None

        self.label = tk.Label(root, text="ỨNG DỤNG KÝ SỐ DSS", font=("Arial", 16, "bold"))
        self.label.pack(pady=20)

        self.create_buttons()
        self.status = tk.Label(root, text="", fg="blue")
        self.status.pack(pady=10)

    def create_buttons(self):
        tk.Button(self.root, text="1. Tạo khóa DSS", width=40, command=self.generate_keys).pack(pady=5)
        tk.Button(self.root, text="2. Chọn file để ký", width=40, command=self.select_file).pack(pady=5)
        tk.Button(self.root, text="3. Tạo mới chữ ký", width=40, command=self.create_file).pack(pady=5)
        tk.Button(self.root, text="4. Ký file", width=40, command=self.sign_file).pack(pady=5)
        tk.Button(self.root, text="5. Gửi file (mô phỏng)", width=40, command=self.send_file).pack(pady=5)
        tk.Button(self.root, text="6. Xác minh chữ ký", width=40, command=self.verify_signature).pack(pady=5)

    def generate_keys(self):
        signer.generate_keys()
        os.makedirs("keys/private", exist_ok=True)
        os.makedirs("keys/public", exist_ok=True)
        signer.save_keys("keys/private/private.pem", "keys/public/public.pem")
        self.status.config(text="✅ Đã tạo khóa DSS!")

    def create_file(self):
        top = tk.Toplevel(self.root)
        top.title("Tạo file mới")
        top.geometry("400x300")

        tk.Label(top, text="Tên file (không có đuôi .txt):").pack(pady=5)
        name_entry = tk.Entry(top, width=40)
        name_entry.pack(pady=5)

        tk.Label(top, text="Nội dung:").pack(pady=5)
        content_text = tk.Text(top, height=8, width=40)
        content_text.pack(pady=5)

        def save_new_file():
            filename = name_entry.get().strip()
            content = content_text.get("1.0", tk.END).strip()
            if not filename:
                messagebox.showerror("Lỗi", "Vui lòng nhập tên file.")
                return
            os.makedirs("files/input", exist_ok=True)
            path = f"files/input/{filename}.txt"
            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(content)
                messagebox.showinfo("Thành công", f"Đã tạo file {filename}.txt")
                top.destroy()
            except Exception as e:
                messagebox.showerror("Lỗi", str(e))

        tk.Button(top, text="Lưu file", command=save_new_file).pack(pady=10)

    def select_file(self):
        file_path = filedialog.askopenfilename(
            title="Chọn file để ký",
            initialdir="files/input",
            filetypes=[("Text files", "*.txt")]
        )
        if file_path:
            self.selected_file = file_path
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    content = f.read()
            except UnicodeDecodeError:
                try:
                    with open(file_path, "r", encoding="utf-16") as f:
                        content = f.read()
                except Exception:
                    messagebox.showerror("Lỗi mở file", "Không thể đọc file. Vui lòng chọn file .txt đúng định dạng.")
                    return

            top = tk.Toplevel(self.root)
            top.title("Xem và chỉnh sửa file")
            top.geometry("500x400")

            text_area = tk.Text(top)
            text_area.insert(tk.END, content)
            text_area.pack(expand=True, fill=tk.BOTH)

            def save_changes():
                new_content = text_area.get("1.0", tk.END)
                try:
                    with open(file_path, "w", encoding="utf-8") as f:
                        f.write(new_content)
                    self.status.config(text=f"📄 Đã chọn: {os.path.basename(file_path)} (đã lưu chỉnh sửa)")
                    messagebox.showinfo("Thành công", "Đã lưu thay đổi vào file.")
                except Exception as e:
                    messagebox.showerror("Lỗi khi lưu", str(e))

            tk.Button(top, text="Lưu chỉnh sửa", command=save_changes).pack(pady=10)

    def sign_file(self):
        if not self.selected_file:
            messagebox.showwarning("Chưa chọn file", "Hãy chọn file trước khi ký!")
            return
        try:
            signer.load_private_key("keys/private/private.pem")
        except:
            messagebox.showerror("Lỗi", "Không tìm thấy khóa bí mật.")
            return

        signature = signer.sign_file(self.selected_file)
        os.makedirs("files/signed", exist_ok=True)
        sig_path = f"files/signed/{os.path.basename(self.selected_file)}.sig"
        with open(sig_path, "wb") as f:
            f.write(signature)
        self.status.config(text="✅ Đã ký file thành công!")

    def send_file(self):
        if not self.selected_file:
            messagebox.showwarning("Chưa chọn file", "Hãy chọn file trước khi gửi!")
            return
        file_name = os.path.basename(self.selected_file)
        sig_file = f"files/signed/{file_name}.sig"
        recv_dir = "files/received"
        os.makedirs(recv_dir, exist_ok=True)
        try:
            with open(self.selected_file, "rb") as f1, open(f"{recv_dir}/{file_name}", "wb") as f2:
                f2.write(f1.read())
            with open(sig_file, "rb") as f1, open(f"{recv_dir}/{file_name}.sig", "wb") as f2:
                f2.write(f1.read())
            messagebox.showinfo("Thành công", "📤 Đã gửi file và chữ ký (mô phỏng)")
        except:
            messagebox.showerror("Lỗi", "Không thể gửi file.")

    def verify_signature(self):
        if not self.selected_file:
            messagebox.showwarning("Chưa chọn file", "Hãy chọn file để xác minh!")
            return

        file_name = os.path.basename(self.selected_file)
        sig_file = f"files/received/{file_name}.sig"
        recv_file = f"files/received/{file_name}"
        if not os.path.exists(sig_file) or not os.path.exists(recv_file):
            messagebox.showerror("Lỗi", "File hoặc chữ ký chưa được gửi.")
            return

        try:
            signer.load_public_key("keys/public/public.pem")
        except:
            messagebox.showerror("Lỗi", "Không tìm thấy khóa công khai.")
            return

        with open(sig_file, "rb") as f:
            signature = f.read()

        result = signer.verify_signature(recv_file, signature)
        if result:
            messagebox.showinfo("Kết quả xác minh", "✅ CHỮ KÝ HỢP LỆ!")
        else:
            messagebox.showerror("Kết quả xác minh", "❌ CHỮ KÝ KHÔNG HỢP LỆ!")

if __name__ == "__main__":
    root = tk.Tk()
    app = DSSGuiApp(root)
    root.mainloop()
